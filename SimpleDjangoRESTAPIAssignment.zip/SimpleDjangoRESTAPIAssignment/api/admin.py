# We will register out Tasklist model here


from django.contrib import admin

from .models import Tasklist
admin.site.register(Tasklist)


